<div class="header">
    <a href="index.php">Главная</a>
    <a href="puzzle.php">Загадки</a>
    <a href="guess.php">Угадайка</a>
    <a href="ugad_2.php">Угадайка на двоих</a>
    <a href="pas_generator.php">Генератор паролей</a>

</div>
